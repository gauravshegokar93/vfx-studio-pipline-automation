const express = require('express');
const router = express.Router();

const {
  getUsers,
  getMe,
  getUserById,
  createUser,
  toggleUserStatus
} = require('../controllers/userController');

router.get('/me', getMe);
router.get('/:id', getUserById);
router.get('/', getUsers);
router.post('/', createUser);
router.put('/:id/status', toggleUserStatus);

module.exports = router;

