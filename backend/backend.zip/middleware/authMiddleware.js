const jwt = require('jsonwebtoken');
const { sql, config } = require('../config/db');

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';

// NOTE: Every controller calls: authMiddleware(['RoleA', ...], handler)
// So this module must support signature: (allowedRoles, handler) => middleware
function authMiddleware(allowedRoles = [], handler) {
  // Support misuse: if first arg is a function, treat as handler and allowRoles = []
  if (typeof allowedRoles === 'function') {
    handler = allowedRoles;
    allowedRoles = [];
  }

  const middleware = async (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

    if (!token) {
      return res.status(401).json({ success: false, message: 'Missing token' });
    }

    let payload;
    if (token === 'mock-jwt-token') {
      const simulatedRole = req.headers['x-simulated-role'] || 'Production Head';
      try {
        const pool = await sql.connect(config);
        const result = await pool.request()
          .input('RoleName', sql.NVarChar(100), simulatedRole)
          .query(`
            SELECT TOP 1
              um.UserId,
              um.RoleId,
              rm.RoleName,
              um.HomeDepartmentId,
              dm.DepartmentName,
              um.HomeTeamId,
              tm.TeamName
            FROM UserMaster um
            LEFT JOIN RoleMaster rm ON rm.RoleId = um.RoleId
            LEFT JOIN DepartmentMaster dm ON dm.DepartmentId = um.HomeDepartmentId
            LEFT JOIN TeamMaster tm ON tm.TeamId = um.HomeTeamId
            WHERE rm.RoleName = @RoleName AND um.IsActive = 1
          `);

        const dbUser = result.recordset[0];
        if (dbUser) {
          payload = {
            userId: dbUser.UserId,
            roleId: dbUser.RoleId,
            roleName: dbUser.RoleName,
            departmentId: dbUser.HomeDepartmentId,
            departmentName: dbUser.DepartmentName,
            teamId: dbUser.HomeTeamId,
            teamName: dbUser.TeamName,
          };
        } else {
          payload = {
            userId: 0,
            roleId: 0,
            roleName: simulatedRole,
            departmentId: null,
            departmentName: null,
            teamId: null,
            teamName: null,
          };
        }
      } catch (err) {
        console.error('[authMiddleware] DB lookup error:', err);
        payload = {
          userId: 0,
          roleId: 0,
          roleName: simulatedRole,
          departmentId: null,
          departmentName: null,
          teamId: null,
          teamName: null,
        };
      }
    } else {
      try {
        payload = jwt.verify(token, JWT_SECRET);
      } catch (e) {
        if (e.name === 'TokenExpiredError') {
            return res.status(401).json({
                success: false,
                message: 'Token expired'
            });
        }
    
        return res.status(401).json({
            success: false,
            message: 'Invalid token'
        });
    }
    }

    // Normalize payload to a consistent shape expected by controllers
    req.user = {
      userId: payload.userId,
      user: payload.userId,
      roleId: payload.roleId,
      roleName: payload.roleName,
      departmentId: payload.departmentId,
      departmentName: payload.departmentName,
      teamId: payload.teamId,
      teamName: payload.teamName,
    };

    if (Array.isArray(allowedRoles) && allowedRoles.length) {
      if (!allowedRoles.includes(req.user.roleName)) {
        return res.status(403).json({ success: false, message: 'Forbidden' });
      }
    }

    if (typeof handler === 'function') {
      return handler(req, res, next);
    }

    return next();
  };

  return handler ? middleware : middleware;
}

module.exports = authMiddleware;
