const bcrypt = require('bcrypt');
const crypto = require('crypto');

const userRepository = require('../repositories/userRepository');

const {
    createUserSchema,
    searchUserSchema
} = require('../validations/userValidation');


// ==========================================
// Get Users
// ==========================================

async function getUsers(query, currentUser) {

    const { error, value } = searchUserSchema.validate(query);

    if (error) {
        throw new Error(error.details[0].message);
    }

    // Department Supervisor restriction
    if (currentUser.roleName === 'Department Supervisor') {
        value.departmentId = currentUser.departmentId;
    }
    const items = await userRepository.getUsers(value);

    return {
        items
    };

}


// ==========================================
// Get Logged User
// ==========================================

async function getMe(user) {

    if (!user) {

        throw new Error('Unauthorized');

    }

    const data = await userRepository.getUserById(
        user.userId || user.UserId
    );

    if (!data) {

        throw new Error('User not found');

    }

    return data;

}

// ==========================================
// Get User By Id
// ==========================================

async function getUserById(userId) {

    const data = await userRepository.getUserById(userId);

    if (!data) {
        throw new Error('User not found');
    }

    return data;

}

// ==========================================
// Create User
// ==========================================

async function createUser(data) {

    const { error, value } = createUserSchema.validate(data);

    if (error) {
        throw new Error(error.details[0].message);
    }

    // Duplicate Employee Code
    const employee = await userRepository.getUserByEmployeeCode(
        value.employeeCode
    );

    if (employee) {
        throw new Error('Employee Code already exists.');
    }

    // Duplicate Email
    const email = await userRepository.getUserByEmail(
        value.email
    );

    if (email) {
        throw new Error('Email already exists.');
    }

    // Resolve RoleId from RoleMaster
    const roleRecord = await userRepository.getRoleByName(value.role);
    if (!roleRecord) {
        throw new Error('Invalid role');
    }
    const roleId = roleRecord.RoleId;

    value.departmentId = value.departmentId || null;
    value.leadId = value.leadId || null;

    const transaction =
        await userRepository.beginTransaction();

    try {

        const userId = await userRepository.getNextUserId();

        let passwordHash = null;
        if (value.password) {
            passwordHash = await bcrypt.hash(value.password, 10);
        }

        // Insert User into UserMaster
        await userRepository.createUser(
            transaction,
            {
                userId,
                employeeCode: value.employeeCode,
                name: value.name,
                email: value.email,
                roleId: roleId,
                departmentId: value.departmentId,
                teamId: null,
                passwordHash: passwordHash,
                isActive: 1
            }
        );

        await userRepository.commitTransaction(
            transaction
        );

        return {

            success: true,

            message: 'User created successfully.',

            userId

        };

    }
    catch (err) {

        await userRepository.rollbackTransaction(
            transaction
        );

        throw err;

    }

}

// ==========================================
// Toggle User Status
// ==========================================

async function toggleUserStatus(userId) {

    const status =
        await userRepository.toggleUserStatus(
            userId
        );

    if (status === null) {

        throw new Error('User not found.');

    }

    return {

        success: true,

        isActive: status

    };

}

// ==========================================
// Change Password
// ==========================================

async function changePassword(userId, currentPassword, newPassword) {

    if (!currentPassword || !newPassword) {
        throw new Error('Current password and new password are required.');
    }

    if (newPassword.length < 6) {
        throw new Error('New password must be at least 6 characters.');
    }

    const user = await userRepository.getPasswordHashByUserId(userId);

    if (!user) {
        throw new Error('User not found.');
    }

    if (!user.IsActive) {
        throw new Error('User account is inactive.');
    }

    const isMatch = await bcrypt.compare(currentPassword, user.PasswordHash);

    if (!isMatch) {
        throw new Error('Current password is incorrect.');
    }

    const passwordHash = await bcrypt.hash(newPassword, 10);

    await userRepository.updatePasswordHash(userId, passwordHash);

    return {
        success: true,
        message: 'Password changed successfully.'
    };

}

// ==========================================
// Reset Password
// ==========================================

async function resetPassword(requesterId, targetUserId, newPassword) {

    if (!newPassword || newPassword.length < 6) {
        throw new Error('New password must be at least 6 characters.');
    }

    const user = await userRepository.getUserById(targetUserId);

    if (!user) {
        throw new Error('User not found.');
    }

    if (!user.IsActive) {
        throw new Error('User account is inactive.');
    }

    const passwordHash = await bcrypt.hash(newPassword, 10);

    await userRepository.updatePasswordHash(targetUserId, passwordHash);

    return {
        success: true,
        message: 'Password reset successfully.'
    };

}

// ==========================================

module.exports = {

    getUsers,

    getMe,

    getUserById,

    createUser,

    toggleUserStatus,

    changePassword,

    resetPassword

};
