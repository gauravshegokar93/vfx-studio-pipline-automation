const { sql, config } = require('../config/db');

async function withDb(callback) {
  const pool = await sql.connect(config);

  try {
    return await callback(pool);
  } finally {
    // mssql pooling handled automatically
  }
}
async function beginTransaction() {
    const pool = await sql.connect(config);

    const transaction = new sql.Transaction(pool);

    await transaction.begin();

    return transaction;
}
async function rollbackTransaction(transaction) {

    if (transaction) {

        await transaction.rollback();

    }

}
async function commitTransaction(transaction) {

    if (transaction) {

        await transaction.commit();

    }

}
// ==========================================
// Get All Users
// ==========================================

async function getUsers(filters = {}) {

  return withDb(async (pool) => {

    const request = pool.request();

    let where = [];
    let whereSql = '';

    if (filters.q) {
      request.input('Q', sql.NVarChar, `%${filters.q}%`);
      where.push(`
        (
          um.FullName LIKE @Q
          OR um.Email LIKE @Q
          OR um.EmployeeCode LIKE @Q
        )
      `);
    }

    if (filters.departmentId) {
      request.input('DepartmentId', sql.BigInt, filters.departmentId);
      where.push('um.HomeDepartmentId = @DepartmentId');
    }

    if (filters.role) {
      request.input('Role', sql.NVarChar, filters.role);
      where.push('rm.RoleName = @Role');
    }

    if (filters.status !== undefined) {
      request.input('IsActive', sql.Bit, filters.status);
      where.push('um.IsActive = @IsActive');
    }

    if (where.length > 0) {
      whereSql = 'WHERE ' + where.join(' AND ');
    }

    const result = await request.query(`
      SELECT
          um.UserId,
          um.EmployeeCode,
          um.FullName,
          um.Email,
          um.RoleId,
          rm.RoleName,
          um.HomeDepartmentId,
          dm.DepartmentName,
          um.HomeTeamId,
          tm.TeamName,
          um.IsActive
      FROM UserMaster um
      LEFT JOIN RoleMaster rm ON rm.RoleId = um.RoleId
      LEFT JOIN DepartmentMaster dm ON dm.DepartmentId = um.HomeDepartmentId
      LEFT JOIN TeamMaster tm ON tm.TeamId = um.HomeTeamId
      ${whereSql}
    `);

    return result.recordset;

  });

}

// ==========================================
// Get User By Id
// ==========================================

async function getUserById(userId) {

  return withDb(async (pool) => {

    const request = pool.request();

    request.input('UserId', sql.BigInt, userId);

    const result = await request.query(`
      SELECT
          um.UserId,
          um.EmployeeCode,
          um.FullName,
          um.Email,
          um.RoleId,
          rm.RoleName,
          um.HomeDepartmentId,
          dm.DepartmentName,
          um.HomeTeamId,
          tm.TeamName,
          um.IsActive
      FROM UserMaster um
      LEFT JOIN RoleMaster rm ON rm.RoleId = um.RoleId
      LEFT JOIN DepartmentMaster dm ON dm.DepartmentId = um.HomeDepartmentId
      LEFT JOIN TeamMaster tm ON tm.TeamId = um.HomeTeamId
      WHERE um.UserId = @UserId
    `);

    return result.recordset[0];

  });

}

// ==========================================
// Get User By Email
// ==========================================

async function getUserByEmail(email) {

  return withDb(async (pool) => {

    const request = pool.request();

    request.input('Email', sql.NVarChar, email);

    const result = await request.query(`
      SELECT
          um.UserId,
          um.EmployeeCode,
          um.FullName,
          um.Email,
          um.RoleId,
          rm.RoleName,
          um.HomeDepartmentId,
          dm.DepartmentName,
          um.HomeTeamId,
          tm.TeamName,
          um.IsActive
      FROM UserMaster um
      LEFT JOIN RoleMaster rm ON rm.RoleId = um.RoleId
      LEFT JOIN DepartmentMaster dm ON dm.DepartmentId = um.HomeDepartmentId
      LEFT JOIN TeamMaster tm ON tm.TeamId = um.HomeTeamId
      WHERE um.Email = @Email
    `);

    return result.recordset[0];

  });

}

// ==========================================
// Get User By Employee Code
// ==========================================

async function getUserByEmployeeCode(employeeCode) {

  return withDb(async (pool) => {

    const request = pool.request();

    request.input('EmployeeCode', sql.NVarChar, employeeCode);

    const result = await request.query(`
      SELECT
          um.UserId,
          um.EmployeeCode,
          um.FullName,
          um.Email,
          um.RoleId,
          rm.RoleName,
          um.HomeDepartmentId,
          dm.DepartmentName,
          um.HomeTeamId,
          tm.TeamName,
          um.IsActive
      FROM UserMaster um
      LEFT JOIN RoleMaster rm ON rm.RoleId = um.RoleId
      LEFT JOIN DepartmentMaster dm ON dm.DepartmentId = um.HomeDepartmentId
      LEFT JOIN TeamMaster tm ON tm.TeamId = um.HomeTeamId
      WHERE um.EmployeeCode = @EmployeeCode
    `);

    return result.recordset[0];

  });

}

// ==========================================
// Create User
// ==========================================

async function createUser(transaction, user) {

  const request = new sql.Request(transaction);

  request.input('UserId', sql.BigInt, user.userId);
  request.input('EmployeeCode', sql.NVarChar(50), user.employeeCode);
  request.input('FullName', sql.NVarChar(255), user.name);
  request.input('Email', sql.NVarChar(255), user.email);
  request.input('RoleId', sql.BigInt, user.roleId);
  request.input('HomeDepartmentId', sql.BigInt, user.departmentId);
  request.input('HomeTeamId', sql.BigInt, user.teamId);
  request.input('PasswordHash', sql.NVarChar(sql.MAX), user.passwordHash);
  request.input('IsActive', sql.Bit, user.isActive !== undefined ? user.isActive : 1);

  await request.query(`
      INSERT INTO UserMaster
      (
          UserId,
          EmployeeCode,
          FullName,
          Email,
          RoleId,
          HomeDepartmentId,
          HomeTeamId,
          PasswordHash,
          IsActive
      )
      VALUES
      (
          @UserId,
          @EmployeeCode,
          @FullName,
          @Email,
          @RoleId,
          @HomeDepartmentId,
          @HomeTeamId,
          @PasswordHash,
          @IsActive
      )
  `);

}

async function getRoleByName(roleName) {
    return withDb(async (pool) => {
        const request = pool.request();
        request.input('RoleName', sql.NVarChar, roleName);
        const result = await request.query(`
            SELECT RoleId FROM RoleMaster WHERE RoleName = @RoleName
        `);
        return result.recordset[0] || null;
    });
}

async function getNextUserId() {
    const result = await withDb(async (pool) => {
        const request = pool.request();
        return await request.query(`
            SELECT NEXT VALUE FOR dbo.SEQ_UserId AS UserId
        `);
    });
    return result.recordset[0]?.UserId || null;
}

async function toggleUserStatus(userId) {

  return withDb(async (pool) => {

    const request = pool.request();

    request.input('UserId', sql.BigInt, userId);

    const check = await request.query(`
        SELECT IsActive
        FROM UserMaster
        WHERE UserId = @UserId
    `);

    if (!check.recordset.length) {

      return null;

    }

    const newStatus = check.recordset[0].IsActive ? 0 : 1;

    const update = pool.request();

    update.input('UserId', sql.BigInt, userId);

    update.input('IsActive', sql.Bit, newStatus);

    await update.query(`
        UPDATE UserMaster
        SET IsActive = @IsActive
        WHERE UserId = @UserId
    `);

    return newStatus === 1;

  });
}

// ==========================================
// Get Password Hash By User Id
// ==========================================

async function getPasswordHashByUserId(userId) {
    return withDb(async (pool) => {
        const request = pool.request();
        request.input('UserId', sql.BigInt, userId);
        const result = await request.query(`
            SELECT UserId, PasswordHash, IsActive
            FROM UserMaster
            WHERE UserId = @UserId
        `);
        return result.recordset[0] || null;
    });
}

// ==========================================
// Update Password Hash
// ==========================================

async function updatePasswordHash(userId, passwordHash) {
    return withDb(async (pool) => {
        const request = pool.request();
        request.input('UserId', sql.BigInt, userId);
        request.input('PasswordHash', sql.NVarChar(sql.MAX), passwordHash);
        await request.query(`
            UPDATE UserMaster
            SET PasswordHash = @PasswordHash,
                ModifiedOn = GETDATE(),
                ModifiedBy = @UserId
            WHERE UserId = @UserId
        `);
    });
}

// ==========================================
// Exports
// ==========================================

module.exports = {

    withDb,

    beginTransaction,

    commitTransaction,

    rollbackTransaction,

    getUsers,

    getUserById,

    getUserByEmail,

    getUserByEmployeeCode,

    createUser,

    getRoleByName,

    getNextUserId,

    getPasswordHashByUserId,

    updatePasswordHash,

    toggleUserStatus

};
