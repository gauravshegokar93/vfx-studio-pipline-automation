const { sql, config } = require('../config/db');
const authMiddleware = require('../middleware/authMiddleware');

async function withDb(callback) {
  const pool = await sql.connect(config);
  try {
    return await callback(pool);
  } finally {
    // mssql pooling handled by library
  }
}

async function getDepartments(req, res) {
  const request = (await sql.connect(config)).request();

  const result = await request.query(`
    SELECT DepartmentId AS id, Name AS name
    FROM Departments
    ORDER BY Name ASC;
  `);

  return res.json({ success: true, items: result.recordset || [] });
}

// bind auth to all handlers
const secured = (handler) => authMiddleware(['Production Head', 'Department Supervisor', 'Lead', 'Artist'], handler);

module.exports = {
  getDepartments: secured(getDepartments),
};

