const authMiddleware = require('../middleware/authMiddleware');
const userService = require('../services/userService');

function secured(handler) {
    return authMiddleware(
        ['Production Head', 'Department Supervisor', 'Lead', 'Artist'],
        handler
    );
}

// ==========================================
// Get Users
// ==========================================

async function getUsers(req, res) {

    try {

        const result = await userService.getUsers(
            req.query,
            req.user
        );

        return res.json({
            success: true,
            ...result
        });

    } catch (err) {

        console.error('[getUsers]', err);

        return res.status(500).json({
            success: false,
            message: err.message
        });

    }

}

// ==========================================
// Get User By Id
// ==========================================

async function getUserById(req, res) {

    try {

        const user = await userService.getUserById(req.params.id);

        return res.json({
            success: true,
            user
        });

    } catch (err) {

        console.error('[getUserById]', err);

        return res.status(500).json({
            success: false,
            message: err.message
        });

    }

}

// ==========================================
// Get Logged User
// ==========================================

async function getMe(req, res) {

    try {

        const user = await userService.getMe(req.user);

        return res.json({
            success: true,
            user
        });

    } catch (err) {

      console.error('[getMe]', err);
  
      return res.status(500).json({
          success: false,
          message: err.message
      });
  
  }

}

// ==========================================
// Create User
// ==========================================

async function createUser(req, res) {

    try {

        const result = await userService.createUser(req.body);

        return res.status(201).json(result);

    } catch (err) {

        console.error('[createUser]', err);

        return res.status(500).json({
            success: false,
            message: err.message
        });

    }

}

// ==========================================
// Toggle Status
// ==========================================

async function toggleUserStatus(req, res) {

    try {

        const result =
            await userService.toggleUserStatus(
                req.params.id
            );

        return res.json(result);

    } catch (err) {

        console.error('[toggleUserStatus]', err);

        return res.status(500).json({
            success: false,
            message: err.message
        });

    }

}

module.exports = {

    getUsers: secured(getUsers),

    getMe: secured(getMe),

    getUserById: secured(getUserById),

    createUser: secured(createUser),

    toggleUserStatus: secured(toggleUserStatus)

};