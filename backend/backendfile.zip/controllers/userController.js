const { sql, config } = require('../config/db');
const authMiddleware = require('../middleware/authMiddleware');
const bcrypt = require('bcrypt');

async function withDb(callback) {
  const pool = await sql.connect(config);
  try {
    return await callback(pool);
  } finally {
    // keep pool open
  }
}

function secured(handler) {
  return authMiddleware(['Production Head', 'Department Supervisor', 'Lead', 'Artist'], handler);
}

async function getUsers(req, res) {
  const user = req.user;

  const { q, departmentId, role, status, page = 1, pageSize = 20 } = req.query || {};
  const pageNum = Math.max(1, parseInt(String(page), 10) || 1);
  const size = Math.min(100, Math.max(1, parseInt(String(pageSize), 10) || 20));
  const offset = (pageNum - 1) * size;

  if (!user) return res.status(401).json({ success: false, message: 'Unauthorized' });

  // RBAC: Department Supervisor can only query own department.
  const where = [];
  const request = (await sql.connect(config)).request();

  if (user.role === 'Department Supervisor') {
    where.push('u.DepartmentId = @RequesterDeptId');
    request.input('RequesterDeptId', sql.UniqueIdentifier, user.departmentId);
  }

  if (departmentId) {
    if (user.role === 'Department Supervisor' && String(departmentId) !== String(user.departmentId)) {
      return res.status(403).json({ success: false, message: 'Forbidden for this department' });
    }
    where.push('u.DepartmentId = @DepartmentId');
    request.input('DepartmentId', sql.UniqueIdentifier, departmentId);
  }

  if (role) {
    where.push('u.Role = @Role');
    request.input('Role', sql.NVarChar, String(role));
  }

  if (status) {
    const st = String(status);
    if (!['Active', 'Inactive'].includes(st)) return res.status(400).json({ success: false, message: 'Invalid status' });
    where.push('u.IsActive = @IsActive');
    request.input('IsActive', sql.Bit, st === 'Active' ? 1 : 0);
  }

  if (q) {
    where.push('(u.Name LIKE @Q OR u.Email LIKE @Q OR u.EmployeeCode LIKE @Q)');
    request.input('Q', sql.NVarChar, `%${String(q)}%`);
  }

  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';

  const totalResult = await request.query(`
    SELECT COUNT(1) AS total
    FROM Users u
    ${whereSql};
  `);

  const itemsResult = await request.query(`
    SELECT
      u.UserId AS id,
      u.EmployeeCode,
      u.Name,
      u.Email,
      u.Role,
      u.DepartmentId AS departmentId,
      u.LeadId AS leadId,
      u.IsActive,
      u.CreatedAt,
      u.CreatedAt AS UpdatedAt
    FROM Users u
    ${whereSql}
    ORDER BY u.CreatedAt DESC
    OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY;
  `.replace('@Offset', String(offset)).replace('@PageSize', String(size)));

  return res.json({
    success: true,
    items: itemsResult.recordset || [],
    total: totalResult.recordset?.[0]?.total ?? 0,
    page: pageNum,
    pageSize: size,
  });
}

async function getMe(req, res) {
  const user = req.user;
  if (!user) return res.status(401).json({ success: false, message: 'Unauthorized' });

  const request = (await sql.connect(config)).request();
  request.input('UserId', sql.UniqueIdentifier, user.userId || user.UserId);

  const result = await request.query(`
    SELECT
      UserId AS id,
      EmployeeCode,
      Name,
      Email,
      Role,
      DepartmentId AS departmentId,
      LeadId AS leadId,
      IsActive AS isActive
    FROM Users
    WHERE UserId = @UserId;
  `);

  if (!result.recordset[0]) return res.status(404).json({ success: false, message: 'Not found' });
  return res.json({ success: true, user: result.recordset[0] });
}

async function createUser(req, res) {
  const { name, employeeCode, email, role, departmentId, leadId, username, password } = req.body || {};

  if (!name || !employeeCode || !email || !role) {
    return res.status(400).json({ success: false, message: 'Name, employee code, email, and role are required' });
  }

  let pool;
  let transaction;
  try {
    pool = await sql.connect(config);
    transaction = new sql.Transaction(pool);
    await transaction.begin();

    const newUserId = require('crypto').randomUUID();
    const avatarUrl = `https://picsum.photos/seed/${employeeCode}/100/100`;

    // 1. Insert into Users
    const userReq = new sql.Request(transaction);
    userReq.input('UserId', sql.UniqueIdentifier, newUserId);
    userReq.input('EmployeeCode', sql.NVarChar(50), employeeCode);
    userReq.input('Name', sql.NVarChar(255), name);
    userReq.input('Email', sql.NVarChar(255), email);
    userReq.input('Role', sql.NVarChar(50), role);
    userReq.input('DepartmentId', sql.UniqueIdentifier, departmentId || null);
    userReq.input('LeadId', sql.UniqueIdentifier, leadId || null);
    userReq.input('AvatarUrl', sql.NVarChar(255), avatarUrl);

    await userReq.query(`
      INSERT INTO Users (UserId, EmployeeCode, Name, Email, Role, DepartmentId, LeadId, IsActive, IsFirstLogin, AvatarUrl, CreatedAt)
      VALUES (@UserId, @EmployeeCode, @Name, @Email, @Role, @DepartmentId, @LeadId, 1, 1, @AvatarUrl, GETDATE())
    `);

    // 2. Insert into UserCredentials if username/password supplied
    if (username && password) {
      const passwordHash = await bcrypt.hash(password, 10);
      const credId = require('crypto').randomUUID();
      const credReq = new sql.Request(transaction);
      credReq.input('CredentialId', sql.UniqueIdentifier, credId);
      credReq.input('UserId', sql.UniqueIdentifier, newUserId);
      credReq.input('Username', sql.NVarChar(255), username);
      credReq.input('PasswordHash', sql.NVarChar(sql.MAX), passwordHash);
      credReq.input('TempPassword', sql.NVarChar(255), password);

      await credReq.query(`
        INSERT INTO UserCredentials (CredentialId, UserId, Username, PasswordHash, TempPassword, LastChangedAt)
        VALUES (@CredentialId, @UserId, @Username, @PasswordHash, @TempPassword, GETDATE())
      `);
    }

    await transaction.commit();
    return res.json({ success: true, userId: newUserId });
  } catch (err) {
    if (transaction) {
      try {
        await transaction.rollback();
      } catch (rErr) {
        console.error('Rollback Error:', rErr);
      }
    }
    console.error('[createUser] Error:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
}

async function getUserCredentials(req, res) {
  try {
    const pool = await sql.connect(config);
    const result = await pool.request().query(`
      SELECT 
        CredentialId AS id,
        UserId AS userId,
        Username AS username,
        TempPassword AS tempPassword,
        LastChangedAt AS lastChangedAt
      FROM UserCredentials
    `);
    return res.json({ success: true, items: result.recordset || [] });
  } catch (err) {
    console.error('[getUserCredentials] Error:', err);
    return res.status(500).json({ success: false, message: 'Failed to fetch credentials' });
  }
}

async function updateUserCredentials(req, res) {
  const { id } = req.params;
  const { username, password } = req.body || {};

  if (!username) {
    return res.status(400).json({ success: false, message: 'Username is required' });
  }

  let pool;
  let transaction;
  try {
    pool = await sql.connect(config);
    transaction = new sql.Transaction(pool);
    await transaction.begin();

    // Check if credential exists
    const checkReq = new sql.Request(transaction);
    checkReq.input('UserId', sql.UniqueIdentifier, id);
    const checkRes = await checkReq.query('SELECT CredentialId FROM UserCredentials WHERE UserId = @UserId');

    if (checkRes.recordset.length > 0) {
      // Update existing credential
      const updateReq = new sql.Request(transaction);
      updateReq.input('UserId', sql.UniqueIdentifier, id);
      updateReq.input('Username', sql.NVarChar(255), username);
      
      let updateSql = 'UPDATE UserCredentials SET Username = @Username, LastChangedAt = GETDATE()';
      if (password) {
        const passwordHash = await bcrypt.hash(password, 10);
        updateReq.input('PasswordHash', sql.NVarChar(sql.MAX), passwordHash);
        updateReq.input('TempPassword', sql.NVarChar(255), password);
        updateSql += ', PasswordHash = @PasswordHash, TempPassword = @TempPassword';
      }
      updateSql += ' WHERE UserId = @UserId';
      await updateReq.query(updateSql);
    } else {
      // Insert new credential if not exists yet
      const credId = require('crypto').randomUUID();
      const insertReq = new sql.Request(transaction);
      insertReq.input('CredentialId', sql.UniqueIdentifier, credId);
      insertReq.input('UserId', sql.UniqueIdentifier, id);
      insertReq.input('Username', sql.NVarChar(255), username);
      
      const pwd = password || 'SMFX123!';
      const passwordHash = await bcrypt.hash(pwd, 10);
      insertReq.input('PasswordHash', sql.NVarChar(sql.MAX), passwordHash);
      insertReq.input('TempPassword', sql.NVarChar(255), pwd);

      await insertReq.query(`
        INSERT INTO UserCredentials (CredentialId, UserId, Username, PasswordHash, TempPassword, LastChangedAt)
        VALUES (@CredentialId, @UserId, @Username, @PasswordHash, @TempPassword, GETDATE())
      `);
    }

    // Force first login on password reset
    if (password) {
      const userUpdateReq = new sql.Request(transaction);
      userUpdateReq.input('UserId', sql.UniqueIdentifier, id);
      await userUpdateReq.query('UPDATE Users SET IsFirstLogin = 1 WHERE UserId = @UserId');
    }

    await transaction.commit();
    return res.json({ success: true });
  } catch (err) {
    if (transaction) {
      try {
        await transaction.rollback();
      } catch (rErr) {}
    }
    console.error('[updateUserCredentials] Error:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
}

async function toggleUserStatus(req, res) {
  const { id } = req.params;
  try {
    const pool = await sql.connect(config);
    // Find the current status first
    const checkRes = await pool.request()
      .input('UserId', sql.UniqueIdentifier, id)
      .query('SELECT IsActive FROM Users WHERE UserId = @UserId');
    
    if (checkRes.recordset.length === 0) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    
    const newStatus = checkRes.recordset[0].IsActive ? 0 : 1;
    
    await pool.request()
      .input('UserId', sql.UniqueIdentifier, id)
      .input('IsActive', sql.Bit, newStatus)
      .query('UPDATE Users SET IsActive = @IsActive WHERE UserId = @UserId');
      
    return res.json({ success: true, isActive: newStatus === 1 });
  } catch (err) {
    console.error('[toggleUserStatus] Error:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
}

module.exports = {
  getUsers: secured(getUsers),
  getMe: secured(getMe),
  createUser: secured(createUser),
  getUserCredentials: secured(getUserCredentials),
  updateUserCredentials: secured(updateUserCredentials),
  toggleUserStatus: secured(toggleUserStatus),
};

