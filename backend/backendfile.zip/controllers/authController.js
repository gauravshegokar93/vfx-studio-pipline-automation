const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { sql, config } = require('../config/db');
const authMiddleware = require('../middleware/authMiddleware');

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'dev-refresh-secret-change-me';

async function withDb(callback) {
  const pool = await sql.connect(config);
  try {
    return await callback(pool);
  } finally {
    // pooling handled by mssql
  }
}

function signAccessToken(user) {
  return jwt.sign(
    {
      userId: user.UserId,
      role: user.Role,
      departmentId: user.DepartmentId,
      leadId: user.LeadId,
    },
    JWT_SECRET,
    { expiresIn: '2h' }
  );
}

function signRefreshToken(user) {
  return jwt.sign(
    {
      userId: user.UserId,
    },
    JWT_REFRESH_SECRET,
    { expiresIn: '30d' }
  );
}

async function login(req, res) {
  const { email, password } = req.body || {};
  if (!email || !password) {
    return res.status(400).json({ success: false, message: 'Email and password are required' });
  }

  const emailNorm = String(email).trim().toLowerCase();

  return withDb(async (pool) => {
    const request = pool.request();
    request.input('Email', sql.NVarChar, emailNorm);

    const result = await request.query(`
      SELECT TOP 1
        UserId, EmployeeCode, Name, Email, PasswordHash, Role, DepartmentId, LeadId, IsActive
      FROM Users
      WHERE Email = @Email;
    `);

    const user = result.recordset[0];
    if (!user) return res.status(401).json({ success: false, message: 'Invalid credentials' });
    if (user.IsActive === 0) return res.status(403).json({ success: false, message: 'User is inactive' });

    const ok = await bcrypt.compare(String(password), user.PasswordHash);
    if (!ok) return res.status(401).json({ success: false, message: 'Invalid credentials' });

    const accessToken = signAccessToken(user);
    const refreshToken = signRefreshToken(user);

    // Store session
    await pool.request()
      .input('UserId', sql.UniqueIdentifier, user.UserId)
      .input('RefreshToken', sql.NVarChar, refreshToken)
      .input('ExpiresAt', sql.DateTime2, new Date(Date.now() + 30 * 24 * 60 * 60 * 1000))
      .input('UserAgent', sql.NVarChar, req.headers['user-agent'] || '')
      .input('IPAddress', sql.NVarChar, req.ip || '')
      .query(`
        INSERT INTO UserSessions(UserId, RefreshToken, ExpiresAt, UserAgent, IPAddress)
        VALUES(@UserId, @RefreshToken, @ExpiresAt, @UserAgent, @IPAddress);
      `);

    return res.json({
      success: true,
      accessToken,
      refreshToken,
      user: {
        id: user.UserId,
        employeeCode: user.EmployeeCode,
        name: user.Name,
        email: user.Email,
        role: user.Role,
        departmentId: user.DepartmentId,
        leadId: user.LeadId,
        isActive: user.IsActive === 1,
      },
    });
  });
}

async function refreshToken(req, res) {
  const { refreshToken } = req.body || {};
  if (!refreshToken) return res.status(400).json({ success: false, message: 'refreshToken is required' });

  const payload = jwt.verify(String(refreshToken), JWT_REFRESH_SECRET);

  return withDb(async (pool) => {
    const request = pool.request();
    request.input('RefreshToken', sql.NVarChar, String(refreshToken));

    const result = await request.query(`
      SELECT TOP 1 s.SessionId, s.UserId, s.ExpiresAt, s.IsRevoked,
        u.Role, u.DepartmentId, u.LeadId, u.EmployeeCode, u.Name, u.Email, u.IsActive
      FROM UserSessions s
      INNER JOIN Users u ON u.UserId = s.UserId
      WHERE s.RefreshToken = @RefreshToken AND s.IsRevoked = 0;
    `);

    const session = result.recordset[0];
    if (!session) return res.status(401).json({ success: false, message: 'Invalid refresh token' });
    if (new Date(session.ExpiresAt).getTime() < Date.now()) {
      return res.status(401).json({ success: false, message: 'Refresh token expired' });
    }
    if (session.IsActive === 0) return res.status(403).json({ success: false, message: 'User is inactive' });

    const user = {
      UserId: session.UserId,
      Role: session.Role,
      DepartmentId: session.DepartmentId,
      LeadId: session.LeadId,
      EmployeeCode: session.EmployeeCode,
      Name: session.Name,
      Email: session.Email,
    };

    const accessToken = signAccessToken(user);
    const newRefreshToken = signRefreshToken(user);

    await pool.request()
      .input('RefreshToken', sql.NVarChar, String(refreshToken))
      .input('NewRefreshToken', sql.NVarChar, newRefreshToken)
      .query(`
        UPDATE UserSessions
        SET RefreshToken = @NewRefreshToken,
            ExpiresAt = DATEADD(day, 30, GETDATE())
        WHERE RefreshToken = @RefreshToken;
      `);

    return res.json({ success: true, accessToken, refreshToken: newRefreshToken });
  });
}

async function logout(req, res) {
  const { refreshToken } = req.body || {};
  if (!refreshToken) return res.status(400).json({ success: false, message: 'refreshToken is required' });

  return withDb(async (pool) => {
    await pool.request()
      .input('RefreshToken', sql.NVarChar, String(refreshToken))
      .query(`
        UPDATE UserSessions
        SET IsRevoked = 1
        WHERE RefreshToken = @RefreshToken;
      `);

    return res.json({ success: true });
  });
}

module.exports = {
  login,
  refreshToken,
  logout,
};

