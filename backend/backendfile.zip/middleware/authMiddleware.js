const jwt = require('jsonwebtoken');
const { sql, config } = require('../config/db');

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';

// NOTE: Every controller calls: authMiddleware(['RoleA', ...], handler)
// So this module must support signature: (allowedRoles, handler) => middleware
function authMiddleware(allowedRoles = [], handler) {
  // Support misuse: if first arg is a function, treat as handler and allowRoles = []
  if (typeof allowedRoles === 'function') {
    handler = allowedRoles;
    allowedRoles = [];
  }

  const middleware = async (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

    if (!token) {
      return res.status(401).json({ success: false, message: 'Missing token' });
    }

    let payload;
    if (token === 'mock-jwt-token') {
      const simulatedRole = req.headers['x-simulated-role'] || 'Production Head';
      try {
        const pool = await sql.connect(config);
        const result = await pool.request()
          .input('Role', sql.NVarChar(50), simulatedRole)
          .query('SELECT TOP 1 UserId, Role, DepartmentId, LeadId FROM Users WHERE Role = @Role AND IsActive = 1');
        
        const dbUser = result.recordset[0];
        if (dbUser) {
          payload = {
            userId: dbUser.UserId,
            role: dbUser.Role,
            departmentId: dbUser.DepartmentId,
            leadId: dbUser.LeadId
          };
        } else {
          payload = {
            userId: '00000000-0000-0000-0000-000000000000',
            role: simulatedRole,
            departmentId: null,
            leadId: null
          };
        }
      } catch (err) {
        console.error('[authMiddleware] DB lookup error:', err);
        payload = {
          userId: '00000000-0000-0000-0000-000000000000',
          role: simulatedRole,
          departmentId: null,
          leadId: null
        };
      }
    } else {
      try {
        payload = jwt.verify(token, JWT_SECRET);
      } catch (e) {
        return res.status(401).json({ success: false, message: 'Invalid token' });
      }
    }

    // Normalize payload to a consistent shape expected by controllers
    req.user = {
      userId: payload.userId,
      user: payload.userId,
      role: payload.role,
      departmentId: payload.departmentId,
      leadId: payload.leadId,
    };

    if (Array.isArray(allowedRoles) && allowedRoles.length) {
      if (!allowedRoles.includes(req.user.role)) {
        return res.status(403).json({ success: false, message: 'Forbidden' });
      }
    }

    if (typeof handler === 'function') {
      return handler(req, res, next);
    }

    return next();
  };

  return handler ? middleware : middleware;
}

module.exports = authMiddleware;


