const express = require('express');
const router = express.Router();

const { 
  getUsers, 
  getMe, 
  createUser, 
  getUserCredentials, 
  updateUserCredentials, 
  toggleUserStatus 
} = require('../controllers/userController');

router.get('/me', getMe);
router.get('/credentials', getUserCredentials);
router.get('/', getUsers);
router.post('/', createUser);
router.put('/:id/credentials', updateUserCredentials);
router.put('/:id/status', toggleUserStatus);

module.exports = router;

