"use client";

import React from "react";
import { useRouter, usePathname } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { hasPermission } from "@/lib/permissions";
import type { Permission } from "@/config/rbac";

const pathnameToPermission: Record<string, Permission> = {
  "/workspace/production-head": "dashboard.production",
  "/workspace/department-supervisor": "dashboard.department",
  "/workspace/lead": "dashboard.lead",
  "/workspace/artist": "dashboard.artist",
};

interface ProtectedRouteProps {
  children: React.ReactNode;
}

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { isAuthenticated, role } = useAuth();
  const router = useRouter();
  const pathname = usePathname();

  if (!isAuthenticated) {
    router.push("/login");
    return null;
  }

  const requiredPermission = pathnameToPermission[pathname];

  if (requiredPermission && role) {
    if (!hasPermission(role, requiredPermission)) {
      router.push("/workspace");
      return null;
    }
  }

  return <>{children}</>;
}
