import axios from 'axios';
import { API_BASE_URL } from '@/config/api';
import { useLuminaStore } from '@/lib/store';

export const apiClient = axios.create({
  baseURL: API_BASE_URL,
});

apiClient.interceptors.request.use((config) => {
  // Always attach mock jwt token and the current simulated role
  const state = useLuminaStore.getState();
  const currentRole = state.currentRole || 'Production Head';
  
  config.headers.Authorization = `Bearer mock-jwt-token`;
  config.headers['x-simulated-role'] = currentRole;
  
  return config;
}, (error) => {
  return Promise.reject(error);
});
