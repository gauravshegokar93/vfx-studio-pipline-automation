
"use client";

import React from 'react';
import { useAuth } from '@/context/AuthContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import ProductionHeadDashboard from '@/app/dashboard/production-head-view';
import LeadDashboardPage from '@/app/lead-dashboard/page';
import DepartmentQueuePage from '@/app/department-queue/page';
import ArtistTasksPage from '@/app/tasks/page';

export default function UnifiedDashboard() {
  const { role } = useAuth();
  
  // Route users to their specific primary dashboard experience
  switch (role) {
    case 'Production Head':
      return <DashboardLayout><ProductionHeadDashboard /></DashboardLayout>;
    case 'Department Supervisor':
      return <DashboardLayout><DepartmentQueuePage /></DashboardLayout>;
    case 'Lead':
      return <DashboardLayout><LeadDashboardPage /></DashboardLayout>;
    case 'Artist':
      return <DashboardLayout><ArtistTasksPage /></DashboardLayout>;
    default:
      return <DashboardLayout><ArtistTasksPage /></DashboardLayout>;
  }
}
